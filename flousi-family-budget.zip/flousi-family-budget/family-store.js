"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const path = require("node:path");

const CURRENCIES = new Set(["MAD", "USD", "EUR", "GBP", "CAD", "SAR", "AED"]);
const MAX_AMOUNT = 99999999900;
const MAX_MEMBERS = 20;
const MAX_EXPENSES = 10000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ID = /^[A-Za-z0-9_-]{24}$/;
const CODE = /^[A-Za-z0-9_-]{32}$/;
const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;
const object = value => value !== null && typeof value === "object" && !Array.isArray(value);
const clone = value => JSON.parse(JSON.stringify(value));
const validAmount = value => Number.isSafeInteger(value) && value > 0 && value <= MAX_AMOUNT;
function validDate(value) {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(value + "T00:00:00Z");
    return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
}
function fail(statusCode, message, code = "INVALID_FAMILY") {
    const error = new Error(message);
    error.statusCode = statusCode;
    error.code = code;
    throw error;
}
function text(value, limit) {
    return typeof value === "string" && value.trim() && value.length <= limit ? value.trim() : null;
}
function member(family, email) {
    if (!family || !family.members.some(item => item.email === email)) {
        fail(404, "Family not found.", "NOT_FOUND");
    }
    return family;
}
function publicFamily(family, email) {
    return {
        id: family.id,
        name: family.name,
        currency: family.currency,
        inviteCode: family.inviteCode,
        members: family.members.map(item => ({ name: item.name, isYou: item.email === email })),
        budgets: { ...family.budgets },
        expenses: family.expenses.filter(item => !item.deleted).map(item => ({
            id: item.id, amountMinor: item.amountMinor, category: item.category,
            note: item.note, date: item.date, authorName: item.authorName
        }))
    };
}
function expenseInput(body) {
    if (!object(body) || !validAmount(body.amountMinor) || !text(body.category, 50) ||
        (body.note !== undefined && (typeof body.note !== "string" || body.note.length > 200)) ||
        !validDate(body.date) || typeof body.clientId !== "string" || !UUID.test(body.clientId)) {
        fail(400, "Expense details are invalid.");
    }
    return { amountMinor: body.amountMinor, category: body.category.trim(),
        note: (body.note || "").trim(), date: body.date, clientId: body.clientId.toLowerCase() };
}
function validStoredFamily(family) {
    if (!object(family) || !ID.test(family.id) || !CODE.test(family.inviteCode) ||
        !text(family.name, 60) || !CURRENCIES.has(family.currency) || !object(family.budgets) ||
        !Array.isArray(family.members) || family.members.length < 1 || family.members.length > MAX_MEMBERS ||
        !Array.isArray(family.expenses) || family.expenses.length > MAX_EXPENSES) return false;
    const emails = new Set();
    if (!family.members.every(item => {
        if (!object(item) || typeof item.email !== "string" || !item.email || !text(item.name, 40) || emails.has(item.email)) return false;
        emails.add(item.email);
        return true;
    })) return false;
    if (!Object.entries(family.budgets).every(([month, amount]) => MONTH.test(month) && validAmount(amount))) return false;
    const ids = new Set();
    const clientIds = new Set();
    return family.expenses.every(item => {
        if (!object(item) || !UUID.test(item.id) || ids.has(item.id) ||
            !validAmount(item.amountMinor) || !text(item.category, 50) ||
            typeof item.note !== "string" || item.note.length > 200 || !validDate(item.date) ||
            typeof item.clientId !== "string" || !UUID.test(item.clientId) || clientIds.has(item.clientId) ||
            !emails.has(item.authorEmail) || !text(item.authorName, 40) ||
            (item.deleted !== undefined && typeof item.deleted !== "boolean")) return false;
        ids.add(item.id);
        clientIds.add(item.clientId);
        return true;
    });
}

// Family records are deliberately separate from users' personal /api/data records.
async function createFamilyStore({ dataDir, pool }) {
    const filename = path.join(dataDir, "families.json");
    let families = {};
    let queue = Promise.resolve();
    let schema;
    if (!pool) {
        try {
            families = JSON.parse(await fs.readFile(filename, "utf8"));
        } catch (error) {
            if (error.code !== "ENOENT") throw error;
            await fs.writeFile(filename, "{}", { flag: "wx", mode: 0o600 });
        }
        const codes = new Set();
        if (!object(families) || !Object.entries(families).every(([id, family]) => {
            if (!validStoredFamily(family) || id !== family.id || codes.has(family.inviteCode)) return false;
            codes.add(family.inviteCode);
            return true;
        })) throw new Error("Flousi family storage is invalid; refusing to overwrite it.");
    }
    // Lazy schema setup also keeps account-only injected PostgreSQL adapters compatible.
    async function ready() {
        if (!schema) {
            schema = pool.query(`CREATE TABLE IF NOT EXISTS flousi_families (
                id TEXT PRIMARY KEY,
                invite_code TEXT UNIQUE NOT NULL,
                data JSONB NOT NULL
            )`).catch(error => { schema = null; throw error; });
        }
        await schema;
    }
    function serialized(operation) {
        const result = queue.then(operation);
        queue = result.catch(() => {});
        return result;
    }
    async function persist(next) {
        const temporary = filename + ".tmp";
        await fs.writeFile(temporary, JSON.stringify(next), { mode: 0o600 });
        await fs.rename(temporary, filename);
        // Publish only after the durable write, never roll back another request's state.
        families = next;
    }
    async function transaction(operation) {
        await ready();
        const client = await pool.connect();
        try {
            await client.query("BEGIN");
            const result = await operation(client);
            await client.query("COMMIT");
            return result;
        } catch (error) {
            try { await client.query("ROLLBACK"); } catch (rollbackError) {
                console.error("Could not roll back a family transaction:", rollbackError);
            }
            throw error;
        } finally {
            client.release();
        }
    }
    // Membership and validation run against the locked record, before any mutation.
    async function mutate(id, email, operation) {
        if (!pool) return serialized(async () => {
            const family = clone(member(families[id], email));
            operation(family);
            const next = { ...families, [id]: family };
            await persist(next);
            return publicFamily(family, email);
        });
        return transaction(async client => {
            const result = await client.query("SELECT data FROM flousi_families WHERE id = $1 FOR UPDATE", [id]);
            const family = clone(member(result.rows[0] && result.rows[0].data, email));
            operation(family);
            await client.query("UPDATE flousi_families SET data = $2::jsonb WHERE id = $1", [id, JSON.stringify(family)]);
            return publicFamily(family, email);
        });
    }
    return {
        async list(email) {
            if (!pool) return serialized(() => Object.values(families)
                .filter(family => family.members.some(item => item.email === email))
                .map(family => publicFamily(family, email)));
            await ready();
            const result = await pool.query("SELECT data FROM flousi_families WHERE data->'members' @> $1::jsonb", [JSON.stringify([{ email }])]);
            return result.rows.map(row => publicFamily(row.data, email));
        },
        async get(id, email) {
            if (!pool) return serialized(() => publicFamily(member(families[id], email), email));
            await ready();
            const result = await pool.query("SELECT data FROM flousi_families WHERE id = $1", [id]);
            return publicFamily(member(result.rows[0] && result.rows[0].data, email), email);
        },
        async create(email, body) {
            if (!object(body) || !text(body.name, 60) || !text(body.displayName, 40) || !CURRENCIES.has(body.currency)) {
                fail(400, "Family name, display name and a supported currency are required.");
            }
            const family = {
                id: crypto.randomBytes(18).toString("base64url"),
                inviteCode: crypto.randomBytes(24).toString("base64url"),
                name: body.name.trim(), currency: body.currency,
                members: [{ email, name: body.displayName.trim() }], budgets: {}, expenses: []
            };
            if (!pool) await serialized(() => persist({ ...families, [family.id]: family }));
            else await transaction(client => client.query(
                "INSERT INTO flousi_families (id, invite_code, data) VALUES ($1, $2, $3::jsonb)",
                [family.id, family.inviteCode, JSON.stringify(family)]));
            return publicFamily(family, email);
        },
        async join(email, body) {
            if (!object(body) || typeof body.code !== "string" || !CODE.test(body.code) || !text(body.displayName, 40)) {
                fail(400, "A valid invitation code and display name are required.");
            }
            const addMember = family => {
                if (!family) fail(404, "Invitation not found.", "NOT_FOUND");
                if (!family.members.some(item => item.email === email)) {
                    if (family.members.length >= MAX_MEMBERS) fail(400, "This family has reached its member limit.", "FAMILY_FULL");
                    family.members.push({ email, name: body.displayName.trim() });
                }
            };
            if (!pool) return serialized(async () => {
                const found = Object.values(families).find(family => family.inviteCode === body.code);
                const family = found && clone(found);
                addMember(family);
                await persist({ ...families, [family.id]: family });
                return publicFamily(family, email);
            });
            return transaction(async client => {
                const result = await client.query("SELECT data FROM flousi_families WHERE invite_code = $1 FOR UPDATE", [body.code]);
                const family = result.rows[0] && clone(result.rows[0].data);
                addMember(family);
                await client.query("UPDATE flousi_families SET data = $2::jsonb WHERE id = $1", [family.id, JSON.stringify(family)]);
                return publicFamily(family, email);
            });
        },
        setBudget(id, email, month, body) {
            return mutate(id, email, family => {
                if (!MONTH.test(month) || !object(body) || !validAmount(body.amountMinor)) fail(400, "Monthly budget is invalid.");
                family.budgets[month] = body.amountMinor;
            });
        },
        addExpense(id, email, body) {
            return mutate(id, email, family => {
                const input = expenseInput(body);
                const previous = family.expenses.find(item => item.clientId === input.clientId);
                if (previous) {
                    if (previous.authorEmail !== email || !Object.keys(input).every(key => previous[key] === input[key])) {
                        fail(409, "This expense retry identifier has already been used with different details.", "IDEMPOTENCY_CONFLICT");
                    }
                    return;
                }
                // Deleted entries retain retry receipts, so retrying a deleted expense cannot resurrect it.
                if (family.expenses.length >= MAX_EXPENSES) fail(400, "This family has reached its expense limit.", "EXPENSE_LIMIT");
                family.expenses.push({ ...input, id: crypto.randomUUID(), authorEmail: email,
                    authorName: family.members.find(item => item.email === email).name });
            });
        },
        deleteExpense(id, email, expenseId) {
            return mutate(id, email, family => {
                const expense = family.expenses.find(item => item.id === expenseId);
                if (!expense) fail(404, "Expense not found.", "NOT_FOUND");
                expense.deleted = true;
            });
        }
    };
}

module.exports = { createFamilyStore };
