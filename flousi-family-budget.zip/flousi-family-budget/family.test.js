"use strict";

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { test } = require("node:test");
const { createServer } = require("./server");
const { createFamilyStore } = require("./family-store");
const copy = value => JSON.parse(JSON.stringify(value));
const emptyData = () => ({ transactions: [], budgets: {}, goals: [], budgetAlerts: [], dailyChallenges: [] });
const expense = (overrides = {}) => ({ amountMinor: 1250, category: "Food", note: "Cash lunch", date: "2026-10-28", clientId: crypto.randomUUID(), ...overrides });
const familyInput = (overrides = {}) => ({ name: "Our household", currency: "MAD", displayName: "Diva", ...overrides });
async function fixture(t, options = {}) {
    const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "flousi-family-"));
    let server;
    let baseUrl;
    async function start() {
        server = await createServer({ dataDir, ...options });
        await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
        baseUrl = "http://127.0.0.1:" + server.address().port;
    }
    async function stop() {
        if (server && server.listening) await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    }
    t.after(async () => { await stop(); await fs.rm(dataDir, { recursive: true, force: true }); });
    await start();
    async function request(url, method = "GET", token, body) {
        const response = await fetch(baseUrl + url, { method,
            headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
            ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
        return { status: response.status, body: await response.json() };
    }
    const accounts = [];
    for (const name of ["owner", "friend", "outsider"]) {
        const response = await request("/api/auth/register", "POST", null, {
            email: name + "@family.example", password: "correct-horse-battery", data: emptyData()
        });
        assert.equal(response.status, 201);
        accounts.push(response.body);
    }
    return { request, owner: accounts[0], friend: accounts[1], outsider: accounts[2], dataDir,
        restart: async () => { await stop(); await start(); } };
}
async function create(f) {
    const response = await f.request("/api/families", "POST", f.owner.token, familyInput());
    assert.equal(response.status, 201);
    return response.body.family;
}
async function join(f, family) {
    const response = await f.request("/api/families/join", "POST", f.friend.token, { code: family.inviteCode, displayName: "Sam" });
    assert.equal(response.status, 200);
    return response.body.family;
}

test("every family route requires authentication, including malformed paths", async t => {
    const f = await fixture(t);
    const id = "a".repeat(24);
    for (const [url, method, body] of [
        ["/api/families", "GET"], ["/api/families", "POST", familyInput()],
        ["/api/families/join", "POST", { code: "a".repeat(32), displayName: "Sam" }],
        ["/api/families/" + id, "GET"],
        ["/api/families/" + id + "/budgets/2026-10", "PUT", { amountMinor: 100 }],
        ["/api/families/" + id + "/expenses", "POST", expense()],
        ["/api/families/" + id + "/expenses/" + crypto.randomUUID(), "DELETE"],
        ["/api/families/invalid", "GET"]
    ]) {
        assert.equal((await f.request(url, method, null, body)).status, 401, method + " " + url);
        assert.equal((await f.request(url, method, "bad.token", body)).status, 401);
    }
});

test("invitation codes are separate from IDs; outsiders see and mutate no family data", async t => {
    const f = await fixture(t);
    const family = await create(f);
    assert.notEqual(family.id, family.inviteCode);
    assert.match(family.id, /^[A-Za-z0-9_-]{24}$/);
    assert.match(family.inviteCode, /^[A-Za-z0-9_-]{32}$/);
    assert.deepEqual((await f.request("/api/families", "GET", f.outsider.token)).body, { families: [] });
    for (const [suffix, method, body] of [
        ["", "GET"], ["/budgets/2026-10", "PUT", { amountMinor: 1000 }],
        ["/expenses", "POST", expense()], ["/expenses", "POST", { amountMinor: -1 }],
        ["/expenses/" + crypto.randomUUID(), "DELETE"]
    ]) {
        const response = await f.request("/api/families/" + family.id + suffix, method, f.outsider.token, body);
        assert.equal(response.status, 404);
        assert.equal(JSON.stringify(response.body).includes(family.inviteCode), false);
    }
    assert.equal((await f.request("/api/families/join", "POST", f.outsider.token, { code: family.id, displayName: "Nope" })).status, 400);
    assert.equal((await f.request("/api/families/join", "POST", f.outsider.token, { code: "a".repeat(32), displayName: "Nope" })).status, 404);
});

test("members share equal management rights, not private personal data or emails", async t => {
    const f = await fixture(t);
    const personal = { ...emptyData(), budgets: { "2026-10": 900 }, transactions: [{
        id: "private", type: "expense", description: "Personal secret", amount: 45, category: "Other", date: "2026-10-28"
    }] };
    assert.equal((await f.request("/api/data", "PUT", f.owner.token, personal)).status, 200);
    const family = await create(f);
    const joined = await join(f, family);
    assert.deepEqual(joined.members, [{ name: "Diva", isYou: false }, { name: "Sam", isYou: true }]);
    assert.equal(joined.inviteCode, family.inviteCode);
    assert.equal((await join(f, family)).members.length, 2, "joining twice does not duplicate a member");
    const base = "/api/families/" + family.id;
    assert.equal((await f.request(base + "/budgets/2026-10", "PUT", f.friend.token, { amountMinor: 500000 })).status, 200);
    const added = await f.request(base + "/expenses", "POST", f.owner.token, expense());
    assert.equal(added.status, 200);
    const shared = (await f.request(base, "GET", f.friend.token)).body.family;
    assert.equal(shared.budgets["2026-10"], 500000);
    assert.equal(shared.expenses[0].authorName, "Diva");
    assert.deepEqual(Object.keys(shared.expenses[0]).sort(), ["amountMinor", "authorName", "category", "date", "id", "note"]);
    assert.equal(JSON.stringify(shared).includes("@"), false);
    assert.equal(JSON.stringify(shared).includes("Personal secret"), false);
    assert.deepEqual((await f.request("/api/data", "GET", f.owner.token)).body.data, personal);
    assert.deepEqual((await f.request("/api/data", "GET", f.friend.token)).body.data, emptyData());
    const removed = await f.request(base + "/expenses/" + shared.expenses[0].id, "DELETE", f.friend.token);
    assert.equal(removed.status, 200, "any member may delete another member's expense");
    assert.equal(removed.body.family.expenses.length, 0);
    assert.equal((await f.request(base + "/expenses/" + shared.expenses[0].id, "DELETE", f.friend.token)).status, 200);
});

test("family and expense validation rejects unsafe values and invalid dates", async t => {
    const f = await fixture(t);
    for (const patch of [{ name: "" }, { name: "x".repeat(61) }, { displayName: " " },
        { displayName: "x".repeat(41) }, { currency: "XYZ" }, { currency: null }]) {
        assert.equal((await f.request("/api/families", "POST", f.owner.token, familyInput(patch))).status, 400);
    }
    const family = await create(f);
    const base = "/api/families/" + family.id;
    for (const amountMinor of [0, -1, 1.5, "100", null, 99999999901, Number.MAX_SAFE_INTEGER]) {
        assert.equal((await f.request(base + "/expenses", "POST", f.owner.token, expense({ amountMinor }))).status, 400);
        assert.equal((await f.request(base + "/budgets/2026-10", "PUT", f.owner.token, { amountMinor })).status, 400);
    }
    for (const patch of [{ category: " " }, { category: "x".repeat(51) }, { note: "x".repeat(201) },
        { note: null }, { date: "2026-02-29" }, { date: "2026-13-01" }, { date: "2026-2-01" },
        { date: null }, { clientId: "not-a-uuid" }, { clientId: null }]) {
        assert.equal((await f.request(base + "/expenses", "POST", f.owner.token, expense(patch))).status, 400, JSON.stringify(patch));
    }
    for (const month of ["2026-13", "2026-00", "2026-1", "invalid"]) {
        assert.equal((await f.request(base + "/budgets/" + month, "PUT", f.owner.token, { amountMinor: 1 })).status, 400);
    }
    assert.equal((await f.request(base + "/budgets/2026-10", "PUT", f.owner.token, { amountMinor: 99999999900 })).status, 200);
    const valid = await f.request(base + "/expenses", "POST", f.owner.token, expense({ date: "2028-02-29", amountMinor: 1, note: undefined }));
    assert.equal(valid.status, 200);
    assert.equal(valid.body.family.expenses[0].note, "");
    for (const currency of ["USD", "EUR", "GBP", "CAD", "SAR", "AED"]) {
        assert.equal((await f.request("/api/families", "POST", f.owner.token, familyInput({ currency }))).status, 201);
    }
});

test("client IDs make concurrent retries idempotent and deleted expenses stay deleted", async t => {
    const f = await fixture(t);
    const family = await create(f);
    await join(f, family);
    const base = "/api/families/" + family.id;
    const input = expense();
    const results = await Promise.all(Array.from({ length: 12 }, () => f.request(base + "/expenses", "POST", f.owner.token, input)));
    results.forEach(result => assert.equal(result.status, 200));
    const read = (await f.request(base, "GET", f.owner.token)).body.family;
    assert.equal(read.expenses.length, 1);
    assert.equal((await f.request(base + "/expenses", "POST", f.owner.token, { ...input, amountMinor: 99 })).status, 409);
    assert.equal((await f.request(base + "/expenses", "POST", f.friend.token, input)).status, 409);
    assert.equal((await f.request(base + "/expenses/" + read.expenses[0].id, "DELETE", f.friend.token)).status, 200);
    const retry = await f.request(base + "/expenses", "POST", f.owner.token, input);
    assert.equal(retry.status, 200);
    assert.equal(retry.body.family.expenses.length, 0);
});

test("concurrent file mutations preserve every expense, member, and budget across restart", async t => {
    const f = await fixture(t);
    const family = await create(f);
    const base = "/api/families/" + family.id;
    const results = await Promise.all([
        join(f, family),
        ...Array.from({ length: 30 }, (_, n) => f.request(base + "/expenses", "POST", f.owner.token, expense({ amountMinor: n + 1 }))),
        f.request(base + "/budgets/2026-10", "PUT", f.owner.token, { amountMinor: 123456 })
    ]);
    results.slice(1).forEach(result => assert.equal(result.status, 200));
    await f.restart();
    const read = await f.request(base, "GET", f.friend.token);
    assert.equal(read.status, 200);
    assert.equal(read.body.family.members.length, 2);
    assert.equal(read.body.family.expenses.length, 30);
    assert.equal(read.body.family.expenses.reduce((sum, item) => sum + item.amountMinor, 0), 465);
    assert.equal(read.body.family.budgets["2026-10"], 123456);
    assert.equal(read.body.family.inviteCode, family.inviteCode);
    assert.equal((await f.request("/api/families", "GET", f.owner.token)).body.families.length, 1);
    assert.equal((await f.request("/api/families", "GET", f.outsider.token)).body.families.length, 0);
});

test("storage enforces member and expense caps without partial mutations", async t => {
    const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "flousi-family-caps-"));
    t.after(() => fs.rm(dataDir, { recursive: true, force: true }));
    let store = await createFamilyStore({ dataDir });
    const family = await store.create("owner@example.com", familyInput());
    await Promise.all(Array.from({ length: 19 }, (_, n) => store.join("person" + n + "@example.com", { code: family.inviteCode, displayName: "Person " + n })));
    await assert.rejects(store.join("overflow@example.com", { code: family.inviteCode, displayName: "Overflow" }), error => error.statusCode === 400);
    assert.equal((await store.get(family.id, "owner@example.com")).members.length, 20);
    const saved = JSON.parse(await fs.readFile(path.join(dataDir, "families.json"), "utf8"));
    saved[family.id].expenses = Array.from({ length: 10000 }, () => ({ ...expense(), id: crypto.randomUUID(), authorEmail: "owner@example.com", authorName: "Diva" }));
    await fs.writeFile(path.join(dataDir, "families.json"), JSON.stringify(saved));
    store = await createFamilyStore({ dataDir });
    await assert.rejects(store.addExpense(family.id, "owner@example.com", expense()), error => error.statusCode === 400);
    assert.equal((await store.get(family.id, "owner@example.com")).expenses.length, 10000);
    const existing = saved[family.id].expenses[0];
    assert.equal((await store.addExpense(family.id, "owner@example.com", existing)).expenses.length, 10000, "valid retries work even at the cap");
});

test("a failed file commit does not publish uncommitted data or lose the next queued mutation", async t => {
    const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "flousi-family-write-error-"));
    t.after(() => fs.rm(dataDir, { recursive: true, force: true }));
    let store = await createFamilyStore({ dataDir });
    const family = await store.create("owner@example.com", familyInput());
    const originalRename = fs.rename;
    let failed = false;
    fs.rename = async (from, to) => {
        if (!failed && to === path.join(dataDir, "families.json")) {
            failed = true;
            throw new Error("Simulated disk write failure");
        }
        return originalRename(from, to);
    };
    try {
        const first = store.addExpense(family.id, "owner@example.com", expense({ note: "Must not appear" }));
        const second = store.addExpense(family.id, "owner@example.com", expense({ note: "Must persist" }));
        await assert.rejects(first, /Simulated disk write failure/);
        const committed = await second;
        assert.equal(committed.expenses.length, 1);
        assert.equal(committed.expenses[0].note, "Must persist");
    } finally {
        fs.rename = originalRename;
    }
    store = await createFamilyStore({ dataDir });
    const read = await store.get(family.id, "owner@example.com");
    assert.equal(read.expenses.length, 1);
    assert.equal(read.expenses[0].note, "Must persist");
});

test("corrupt family storage fails closed without overwriting data", async t => {
    const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "flousi-family-corrupt-"));
    t.after(() => fs.rm(dataDir, { recursive: true, force: true }));
    const filename = path.join(dataDir, "families.json");
    const invalid = JSON.stringify({ example: { name: "Broken" } });
    await fs.writeFile(filename, invalid);
    await assert.rejects(createFamilyStore({ dataDir }), /family storage is invalid/);
    assert.equal(await fs.readFile(filename, "utf8"), invalid);
});

// SQL contract adapter, not an actual PostgreSQL engine. It asserts BEGIN/COMMIT,
// models exclusive locks until transaction end, and rejects unexpected SQL.
function sqlContractPool() {
    const records = new Map();
    const log = [];
    let tail = Promise.resolve();
    async function query(sql, values = []) {
        log.push(sql);
        if (sql.includes("CREATE TABLE IF NOT EXISTS flousi_families")) return { rows: [] };
        if (sql.includes("WHERE data->'members' @>")) {
            const [{ email }] = JSON.parse(values[0]);
            return { rows: [...records.values()].filter(item => item.data.members.some(member => member.email === email)).map(copy) };
        }
        if (sql === "SELECT data FROM flousi_families WHERE id = $1") return { rows: records.has(values[0]) ? [copy(records.get(values[0]))] : [] };
        throw Error("Unexpected nontransactional family query: " + sql);
    }
    return { query, log, records, async connect() {
        let active = false;
        let locked = false;
        let unlock;
        let staged;
        return { async query(sql, values = []) {
            log.push(sql);
            if (sql === "BEGIN") { assert.equal(active, false); active = true; return { rows: [] }; }
            assert.equal(active, true, "all writes must be inside a transaction");
            if (sql === "COMMIT" || sql === "ROLLBACK") {
                if (sql === "COMMIT" && staged) for (const [id, row] of staged) records.set(id, row);
                active = false;
                if (unlock) unlock();
                return { rows: [] };
            }
            if (!locked) {
                const previous = tail;
                tail = new Promise(resolve => { unlock = resolve; });
                await previous;
                locked = true;
                staged = new Map([...records].map(([id, row]) => [id, copy(row)]));
            }
            if (sql.startsWith("INSERT INTO flousi_families")) {
                assert.equal(staged.has(values[0]), false);
                staged.set(values[0], { data: JSON.parse(values[2]), code: values[1] });
                return { rows: [], rowCount: 1 };
            }
            if (sql.startsWith("SELECT data FROM flousi_families WHERE") && sql.endsWith("FOR UPDATE")) {
                const row = sql.includes("invite_code =") ? [...staged.values()].find(item => item.code === values[0]) : staged.get(values[0]);
                return { rows: row ? [copy(row)] : [] };
            }
            if (sql === "UPDATE flousi_families SET data = $2::jsonb WHERE id = $1") {
                assert.ok(locked);
                const row = staged.get(values[0]);
                assert.ok(row);
                row.data = JSON.parse(values[1]);
                return { rows: [], rowCount: 1 };
            }
            throw Error("Unexpected transactional family query: " + sql);
        }, release() { assert.equal(active, false, "transaction must end before releasing connection"); } };
    } };
}

test("PostgreSQL contract uses transactions and row locks; sharing, retries, privacy and restart persist", async () => {
    const pool = sqlContractPool();
    let store = await createFamilyStore({ dataDir: os.tmpdir(), pool });
    const family = await store.create("owner@example.com", familyInput());
    await store.join("friend@example.com", { code: family.inviteCode, displayName: "Friend" });
    await assert.rejects(store.addExpense(family.id, "outsider@example.com", expense()), error => error.statusCode === 404);
    await assert.rejects(store.setBudget(family.id, "owner@example.com", "2026-10", { amountMinor: -1 }), error => error.statusCode === 400);
    const duplicate = expense();
    await Promise.all([
        ...Array.from({ length: 15 }, () => store.addExpense(family.id, "owner@example.com", expense())),
        ...Array.from({ length: 5 }, () => store.addExpense(family.id, "friend@example.com", duplicate)),
        store.setBudget(family.id, "friend@example.com", "2026-10", { amountMinor: 550000 })
    ]);
    store = await createFamilyStore({ dataDir: os.tmpdir(), pool });
    const read = await store.get(family.id, "owner@example.com");
    assert.equal(read.expenses.length, 16);
    assert.equal(read.budgets["2026-10"], 550000);
    assert.equal(read.members.length, 2);
    assert.equal(JSON.stringify(read).includes("@"), false);
    assert.equal((await store.list("friend@example.com")).length, 1);
    assert.deepEqual(await store.list("outsider@example.com"), []);
    const deleted = await store.deleteExpense(family.id, "friend@example.com", read.expenses[0].id);
    assert.equal(deleted.expenses.length, 15);
    assert.equal(pool.log.filter(sql => sql === "BEGIN").length,
        pool.log.filter(sql => sql === "COMMIT" || sql === "ROLLBACK").length);
    assert.ok(pool.log.filter(sql => sql.endsWith("FOR UPDATE")).length >= 24);
    assert.ok(pool.log.includes("ROLLBACK"));
});


test("personal cash payment method survives sync, login and restart while legacy entries stay compatible", async t => {
    const f = await fixture(t);
    const legacy = { id: "legacy-payment", type: "expense", description: "Legacy purchase", amount: 12,
        category: "Food", date: "2026-10-28" };
    const cash = { ...legacy, id: "cash-payment", description: "Cash purchase", paymentMethod: "cash" };
    const data = { ...emptyData(), transactions: [legacy, cash] };
    const saved = await f.request("/api/data", "PUT", f.owner.token, data);
    assert.equal(saved.status, 200);
    assert.deepEqual(saved.body.data, data);
    assert.deepEqual((await f.request("/api/data", "GET", f.owner.token)).body.data, data);
    const login = await f.request("/api/auth/login", "POST", null, {
        email: f.owner.email, password: "correct-horse-battery"
    });
    assert.equal(login.status, 200);
    assert.deepEqual(login.body.data, data);
    for (const paymentMethod of ["card", "bank", "", null, 1, false, {}, []]) {
        const invalid = { ...emptyData(), transactions: [{ ...cash, paymentMethod }] };
        assert.equal((await f.request("/api/data", "PUT", f.owner.token, invalid)).status, 400);
    }
    assert.deepEqual((await f.request("/api/data", "GET", f.owner.token)).body.data, data);
    await f.restart();
    const read = (await f.request("/api/data", "GET", f.owner.token)).body.data;
    assert.deepEqual(read, data);
    assert.equal(Object.hasOwn(read.transactions[0], "paymentMethod"), false);
    assert.equal(read.transactions[1].paymentMethod, "cash");
});
